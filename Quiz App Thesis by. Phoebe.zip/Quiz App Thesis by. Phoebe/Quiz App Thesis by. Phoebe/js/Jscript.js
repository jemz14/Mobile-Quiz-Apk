// C:\Users\acer\Videos\Deadpool.2016.1080p.HDRip.KORSUB.x264.AAC2.0-STUTTERSHIT
console.log("xx");

var img = 'img.jpg';
var var_img = "<img src='"+img+"' />";

// var var_vid ='<video controls="" autoplay="" name="media"><source src="file:///C:/Users/acer/Desktop/hello%20app/slider_FERRARI-GTC4LUSSO_film_ufficiale_2-2000_HBRRN3.webm" type="video/webm"></video>';
var var_vid ='<video controls="" autoplay="" name="media"><source src="file:///C:/Users/acer/Desktop/hello%20app/slider_FERRARI-GTC4LUSSO_film_ufficiale_2-2000_HBRRN3.webm"></video>';
$('#img').html(var_img);
$('#vid').html(var_vid);